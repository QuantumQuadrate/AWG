#ifndef _SD_OBJECT_C_H_
#define _SD_OBJECT_C_H_

#include "../common/SD_DLL_API.h"

/******************** SD_Object Functions *****************************/

SD_DLL_API_C const char* __cdecl SD_GetErrorMessage(int errorNumber);

#endif
